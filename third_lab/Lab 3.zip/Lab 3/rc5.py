from typing import List


class RC5:
    def __init__(self, key: bytes, w: int = 32, r: int = 12):
        self.w = w
        self.R = r
        self.mod = 2 ** w
        self.mask = self.mod - 1

        if w == 16:
            self.P, self.Q = 0xB7E1, 0x9E37
        elif w == 32:
            self.P, self.Q = 0xB7E15163, 0x9E3779B9
        elif w == 64:
            self.P, self.Q = 0xB7E151628AED2A6B, 0x9E3779B97F4A7C15
        else:
            raise ValueError("Unsupported w. Must be 16, 32, or 64.")

        self.S = self._expand_key(key)

    def _left_rotate(self, val: int, shift: int) -> int:
        shift %= self.w
        return ((val << shift) & self.mask) | (val >> (self.w - shift))

    def _right_rotate(self, val: int, shift: int) -> int:
        shift %= self.w
        return (val >> shift) | ((val << (self.w - shift)) & self.mask)

    def _expand_key(self, key: bytes) -> List[int]:
        u = self.w // 8
        b = len(key)

        key_padded = bytearray(key)
        while len(key_padded) % u != 0:
            key_padded.append(0x00)

        c = len(key_padded) // u if len(key_padded) > 0 else 1
        if b == 0:
            key_padded = bytearray(u)

        L = [int.from_bytes(key_padded[i * u: i * u + u], byteorder='little') for i in range(c)]

        t = 2 * self.R + 2
        S = [self.P]
        for i in range(1, t):
            S.append((S[i - 1] + self.Q) & self.mask)

        i = j = A = B = 0
        for _ in range(3 * max(c, t)):
            A = S[i] = self._left_rotate((S[i] + A + B) & self.mask, 3)
            B = L[j] = self._left_rotate((L[j] + A + B) & self.mask, (A + B) & self.mask)
            i = (i + 1) % t
            j = (j + 1) % c

        return S

    def encrypt_block(self, data: bytes) -> bytes:
        u = self.w // 8
        A = int.from_bytes(data[:u], byteorder='little')
        B = int.from_bytes(data[u:], byteorder='little')

        A = (A + self.S[0]) & self.mask
        B = (B + self.S[1]) & self.mask

        for i in range(1, self.R + 1):
            A = (self._left_rotate(A ^ B, B) + self.S[2 * i]) & self.mask
            B = (self._left_rotate(B ^ A, A) + self.S[2 * i + 1]) & self.mask

        return A.to_bytes(u, byteorder='little') + B.to_bytes(u, byteorder='little')

    def decrypt_block(self, data: bytes) -> bytes:
        u = self.w // 8
        A = int.from_bytes(data[:u], byteorder='little')
        B = int.from_bytes(data[u:], byteorder='little')

        for i in range(self.R, 0, -1):
            B = self._right_rotate((B - self.S[2 * i + 1]) & self.mask, A) ^ A
            A = self._right_rotate((A - self.S[2 * i]) & self.mask, B) ^ B

        B = (B - self.S[1]) & self.mask
        A = (A - self.S[0]) & self.mask

        return A.to_bytes(u, byteorder='little') + B.to_bytes(u, byteorder='little')

    def _pad(self, data: bytes) -> bytes:
        block_size = (self.w // 8) * 2
        padding_len = block_size - (len(data) % block_size)
        return data + bytes([padding_len] * padding_len)

    def _unpad(self, data: bytes) -> bytes:
        padding_len = data[-1]
        return data[:-padding_len]

    def encrypt_cbc(self, data: bytes, iv: bytes) -> bytes:
        block_size = (self.w // 8) * 2
        padded_data = self._pad(data)
        result = bytearray()
        prev_block = iv[:block_size].ljust(block_size, b'\x00')

        for i in range(0, len(padded_data), block_size):
            block = padded_data[i:i + block_size]
            xored = bytes(a ^ b for a, b in zip(block, prev_block))
            enc_block = self.encrypt_block(xored)
            result.extend(enc_block)
            prev_block = enc_block

        return bytes(result)

    def decrypt_cbc(self, data: bytes, iv: bytes) -> bytes:
        block_size = (self.w // 8) * 2
        result = bytearray()
        prev_block = iv[:block_size].ljust(block_size, b'\x00')

        for i in range(0, len(data), block_size):
            block = data[i:i + block_size]
            dec_block = self.decrypt_block(block)
            xored = bytes(a ^ b for a, b in zip(dec_block, prev_block))
            result.extend(xored)
            prev_block = block

        return self._unpad(bytes(result))